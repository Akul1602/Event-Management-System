module EventManagementSystem {
}